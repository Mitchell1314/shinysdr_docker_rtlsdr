print "hello, test is successful."

from __future__ import absolute_import, division, print_function, unicode_literals
# pylint: disable=import-error, no-member, no-name-in-module
import shinysdr.test.nonexistent_module_in_dep
print(shinysdr.test.nonexistent_module_in_dep)
